#pragma once
class Class
{
public:
	bool t = true;

private:


}toggle;
